package com.cg.banking.utility;

import java.util.HashMap;

import com.cg.banking.beans.Customer;

public class BankingUtility {
	public HashMap<Integer, Customer> customers=new HashMap<>();
	public int CUSTOMER_ID_COUNTER=100,ACCOUNT_ID_COUNTER=111,TRANSACTION_ID_COUNTER=1;

}
