

package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;

public class BankingDAOServicesImpl implements BankingDAOServices{
	BankingUtility utility=new BankingUtility();
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(utility.CUSTOMER_ID_COUNTER++);
		utility.customers.put(customer.getCustomerId(), customer);
		return  customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(utility.ACCOUNT_ID_COUNTER++);
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);		
		account.setStatus("active");
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);	
		return true;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		Random random=new Random();
		account.setPinNumber(random.nextInt(10000));
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);
		return account.getPinNumber();
		
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId(utility.TRANSACTION_ID_COUNTER++);
		if(getAccount(customerId, accountNo)!=null){
		getAccount(customerId, accountNo).getTransactions().put(transaction.getTransactionId(), transaction);
		return true;
		}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		utility.customers.remove(customerId);
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		getCustomer(customerId).getAccounts().remove(accountNo);
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		
		return utility.customers.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {

		return utility.customers.get(customerId).getAccounts().get(accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		
		return new ArrayList<>(utility.customers.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {

		return new ArrayList<>(utility.customers.get(customerId).getAccounts().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransactions().values());
		
	}
		
	

}
