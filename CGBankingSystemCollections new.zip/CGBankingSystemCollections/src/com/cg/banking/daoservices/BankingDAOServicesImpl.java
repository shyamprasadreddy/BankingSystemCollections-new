package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices{
	
	HashMap<Integer, Customer> customers=new HashMap<>();
	private int CUSTOMER_ID_COUNTER=100,ACCOUNT_ID_COUNTER=111,TRANSACTION_ID_COUNTER=1;
	
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customers.put(customer.getCustomerId(), customer);
		return  customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(ACCOUNT_ID_COUNTER++);
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);		
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);	
		return true;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		Random random=new Random();
		account.setPinNumber(random.nextInt(10000));
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);
		return account.getPinNumber();
		
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId(TRANSACTION_ID_COUNTER++);
		if(getAccount(customerId, accountNo)!=null){
		getAccount(customerId, accountNo).getTransactions().put(transaction.getTransactionId(), transaction);
		return true;
		}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		getCustomer(customerId).getAccounts().remove(accountNo);
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		
		return customers.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {

		return customers.get(customerId).getAccounts().get(accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		
		return new ArrayList<>(customers.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {

		return new ArrayList<>(customers.get(customerId).getAccounts().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransactions().values());
		
	}
		
	

}
